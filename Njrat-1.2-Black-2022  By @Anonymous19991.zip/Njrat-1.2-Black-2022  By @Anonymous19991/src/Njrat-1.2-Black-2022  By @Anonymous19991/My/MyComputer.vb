﻿Imports System
Imports System.CodeDom.Compiler
Imports System.ComponentModel
Imports System.Diagnostics
Imports Microsoft.VisualBasic.Devices

Namespace NJRAT.My
	' Token: 0x02000003 RID: 3
	<EditorBrowsable(EditorBrowsableState.Never)>
	<GeneratedCode("MyTemplate", "8.0.0.0")>
	Friend Class MyComputer
		Inherits Computer

		' Token: 0x06000006 RID: 6 RVA: 0x00148BC4 File Offset: 0x00146FC4
		<DebuggerHidden()>
		<EditorBrowsable(EditorBrowsableState.Never)>
		Public Sub New()
		End Sub
	End Class
End Namespace
